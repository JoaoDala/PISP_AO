
document.addEventListener('DOMContentLoaded', function() {

    console.log('PISP-ANGOLA carregado com sucesso!');
});